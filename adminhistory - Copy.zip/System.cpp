/*
 * System.cpp
 *
 *  Created on: Oct 23, 2020
 *      Author: user
 */

#include "System.h"
#include <windows.h>
#include <stdio.h>




System::System(){
	// TODO Auto-generated constructor stub
	size=0;
}

System::~System() {
	// TODO Auto-generated destructor stub

}

//******************************************************************

bool System::found(const string& name){
	std::ifstream infile(name);
	return infile.good();
}

//*******************************************************************



//*******************************************************************



//*******************************************************************
// mkdir command
void System::createDir(const string& name){

	int check = _mkdir(name.c_str());
	if(check == 0)cout << "Directory " << name << " has been made" << endl;
	else
		cout <<"Cannot make Directory " << name << " !" << endl;
}

//******************************************************************
//rmdir command
void System::removeDir(const string& name){
	if(this->user != "admin"){
		cout << this->user << " is not eligible to delete Directory" << name << endl;
		return;
	}
	DIR *d = opendir(name.c_str());
	struct dirent * dp;
	short cnt =0,check;
	if (d == NULL) {
		cout << "Can't find Directory in the given name -> " << name << endl;
		return;
	}
	while ((dp = readdir(d)) != NULL) {
			if(dp->d_name != NULL && dp->d_name != '\0'){
				cnt++;
			}
	}
	if(cnt == 2){
		 check = _rmdir(name.c_str());
	}
	if(check == 0) cout << "Directory has been deleted succefully"<<endl;

	else
		cout << "Error deleting give folder"<<endl;

}

//*******************************************************************


void System::chmod(const string& num, const string& file){
	if(!found(file)) throw (FileNotFoundException(file));
	int number = std::stoi( num );
	if(number < 0 || number > 7) throw(Errors::numError());
	if(file.find("history.txt")){
		if(!check(file)) return;
	}

	string str="";
	str +="chmod ";
	str += num;
	str +="55 ";
	str += file;
	system(str.data());


}


//*******************************************************************
//ls command
void System::listDir(){
	char buff[100];
	GetCurrentDir( buff, 100);
	string current_working_dir(buff);
	struct dirent *entry;
	DIR *dir = opendir(current_working_dir.c_str());
	if (dir == NULL) {
	      return;
	}
	string userFile = user;
	userFile.append("history.txt");
	if(user == "admin"){
		while ((entry = readdir(dir)) != NULL){
			string temp = entry->d_name;
			if((temp.find(".cpp")) != std::string::npos){
				continue;
			}
			if((temp.find(".h")) != std::string::npos){
				continue;
			}
			cout << entry->d_name << endl;
		}
		closedir(dir);
		return;
	}
	while ((entry = readdir(dir)) != NULL) {
		string temp = entry->d_name;
		if ((temp.find("history.txt")) != std::string::npos) {
		    if(temp != userFile) continue;
		}
		if((temp.find(".cpp")) != std::string::npos){
			continue;
		}
		if((temp.find(".h")) != std::string::npos){
			continue;
		}

		cout << entry->d_name << endl;
	}
	closedir(dir);
}

//*******************************************************************

bool System::check(const string& temp){
	string username = user;
	username.append("history.txt");
	if (temp.find("history.txt") != std::string::npos) {
			if (temp != username){
				return false;
			}
		}
	return true;
}

//*******************************************************************
int System::getFileSize(const string& name){
	ifstream infile(name);
	infile.seekg(0, std::ios::end);
	int file_size = infile.tellg();
	infile.close();
	return file_size;
}

//*******************************************************************

void System::editFile(const string& name){
	if (user == "admin"){
		string filename = "notepad \"" + name + "\"";
		system(filename.c_str());
		return;
	}
	string username = user;
	username.append("history.txt");
	if (name.find("history") != std::string::npos) {
		if (name != username){
			cout << "User " << user <<" is not eligible to edit another user file"<< endl;
			return;
		}
	}
	string filename = "notepad \"" + name + "\"";
	system(filename.c_str());
}


//*******************************************************************

void System::read(const string& name, const int& pos){
	if(!found(name)) throw (FileNotFoundException(name));
	int size = getFileSize(name);
	if(pos > size) throw Errors::readError();
	ifstream infile(name);
	char c;
	infile.seekg(pos);
	infile >> c;
	cout << c;
	infile.close();
}

//*******************************************************************

void System::writeChar(const string& name, const int& pos, const char& character){
	if(!found(name)) throw (FileNotFoundException(name));
	int size = getFileSize(name);
	if(pos > size) throw Errors::writeError();
	ofstream out(name);
	out.seekp(pos);
	out << character;
	out.close();
}

//********************************************************************

void System::write(const string& name, const string& line){
	std::ofstream out;
	if(line.size() == 0 )return;
	if(user == "admin"){
		out.open(name,std::ios::app);
		out << line+"\n";
		out.close();
		return;
	}
	string username = user;
	username.append("history.txt");
	if (name.find("history") != std::string::npos) {
		if (name != username){
			cout << "User " << user <<" is not eligible to edit another user file"<< endl;
			return;
		}
	}
	out.open(name,std::ios::app);
	out << line+"\n";
	out.close();
}


//********************************************************************

void System::printExitMessage(){
	cout << "Program is shutting down, GoodBye!" << endl;
}
//********************************************************************

void System::touch(const string& name){
	if(!found(name)){
		addFile(name);
		return;
	}
	SYSTEMTIME thesystemtime;
	GetSystemTime(&thesystemtime);
	FILETIME thefiletime;
	SystemTimeToFileTime(&thesystemtime,&thefiletime);
	HANDLE filename = CreateFile(name.data(), FILE_WRITE_ATTRIBUTES, FILE_SHARE_READ|FILE_SHARE_WRITE, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
	SetFileTime(filename,(LPFILETIME) NULL,(LPFILETIME) NULL,&thefiletime);
	CloseHandle(filename);


}

//********************************************************************

void System::addFile(const string& name){
	std::ofstream outfile (name);
	outfile << std::endl;
	outfile.close();
}

//*********************************************************************

void System::copy(const string& src,const string& tar){

	if(!found(src)) throw (FileNotFoundException(src));
	if(!found(tar)) touch(tar);
	if (user == "admin" || (check(src) && check(tar))){
		ifstream input(src.data());
		ofstream output(tar.data());
		output.clear();
		string temp;
		while(!input.eof()){
			input>>temp;
			output<<temp;
		}
	}
}

//*********************************************************************

void System::rem(const string& name){
	if(!found(name)) throw (FileNotFoundException(name));
	if(user == "admin"){
		remove(name.data());
		return;
	}
	bool check1 = check(name);
	if(!check1){
		cout << "User " << user << " is not eligible to delete " << name << endl;
		return;
	}
	remove(name.data());
}

//*********************************************************************

void System::move(const string& src,const string& tar){
	copy(src,tar);
	rem(src);
}

//*********************************************************************

void System::cat(const string& name)
{
	if(!found(name)) throw (FileNotFoundException(name));
    string temp;
    ifstream input(name.data());
    if(user == "admin"){
    	while(!input.eof()){
    		getline(input,temp);
    	    cout<<temp<<"\n";
    	}
    	input.close();
    }
    if (!(check(name))){
    	cout << "User " << user << " is not eligible to view " << name <<" data" <<endl;
    	input.close();
    	return;
    }
    while(!input.eof()){
        getline(input,temp);
         cout<<temp<<"\n";
    }
    input.close();
}

//*********************************************************************

void System::head(const string& name , const int& num)
{
	if(!found(name)) throw (FileNotFoundException(name));
    int temp = num;
    string temp1;
    ifstream input(name.data());
    if(user == "admin"){
    	while(!input.eof() && temp-- != 0){
    		getline(input,temp1);
    	    cout<<temp1<<"\n";
    	}
    	input.close();
    }
    if (!(check(name))){
    	cout << "User " << user << " is not eligible to view " << name <<" data" <<endl;
        input.close();
        return;
    }
    while(!input.eof() && temp-- != 0){
        getline(input,temp1);
         cout<<temp1<<"\n";
    }
    input.close();
}

//********************************************************************

void System::showPrivacy(const string& file){
	if(!found(file)) throw (FileNotFoundException(file));
	struct stat st;
	string s="";
	if(user == "admin"){
		if(stat(file.data(), &st) == 0){
			mode_t perm = st.st_mode;
			s += (perm & S_IRUSR) ? 'r' : '-';
			s += (perm & S_IWUSR) ? 'w' : '-';
			s += (perm & S_IXUSR) ? 'x' : '-';
			cout << s << endl;;
		}
		return;
	}
	if (!(check(file))){
	    	cout << "User " << user << " is not eligible to view " << file <<" permissions" <<endl;
	        return;
	}
	if(stat(file.data(), &st) == 0){
		mode_t perm = st.st_mode;
		s += (perm & S_IXUSR) ? 'x' : '-';
	    s += (perm & S_IRUSR) ? 'r' : '-';
	    s += (perm & S_IWUSR) ? 'w' : '-';

	    cout << s << endl;
	}
}

//*******************************************************************

void System::diff(const string& file1, const string& file2){
	if(!found(file1)) throw (FileNotFoundException(file1));
	if(!found(file2)) throw (FileNotFoundException(file2));
	if (file1.find("history.txt") || file2.find("history.txt")){
		if(!check(file1) || !check(file2)){
			cout << "User " << user << " is not eligible to view one of the files contents" <<endl;
			return;
		}
	}
	string s = "diff ";
	s += file1;
	s+= " ";
	s += file2;
	system(s.data());
}

//********************************************************************

void System::tail(const string& name , const int& num)
{
	if(num <= 0) {
		cout << "Error with negative number in tail\n";
		cout << "your parameter is = " << num << endl;
		return;
	}
	std::vector<string> myvector;
	string temp;
	if(!found(name)) throw (FileNotFoundException(name));
	ifstream input(name.data());
	if(user == "admin"){
		while(!input.eof())
		{
			getline(input,temp);
			myvector.push_back(temp);
		}
		input.close();
		int size = myvector.size();
		if(num >= size){
			for (int i=0; i<size; ++i)
				std::cout <<myvector[i] << '\n';
			return;
		}else{
			int temp1 = size - num;
			for (int i=0; i<temp1; ++i)
			myvector.erase(myvector.begin());
		}
		for (unsigned i=0; i<=myvector.size(); ++i)
			std::cout <<myvector[i] << '\n';
		return;
	}
	if (!(check(name))){
		cout << "User " << user << " is not eligible to view " << name <<" data" <<endl;
		input.close();
		return;
	}
	while(!input.eof()){
		getline(input,temp);
		myvector.push_back(temp);
	}
	input.close();
	int size = myvector.size();
	if(num >= size){
		for (int i=0; i<size; ++i)
			std::cout <<myvector[i] << '\n';
		return;
	}else{
		int temp1 = size - num;
		for (int i=0; i<temp1; ++i)
			myvector.erase(myvector.begin());
	}
	for (unsigned i=0; i<=myvector.size(); ++i)
		std::cout <<myvector[i] << '\n';
}

//**********************************************************************

bool System::is_number(const std::string& s){
	std::string::const_iterator it = s.begin();
	while (it != s.end() && std::isdigit(*it)) ++it;
	return !s.empty() && it == s.end();
}

//***********************************************************************

void System::concatFiles(const string& from, const string& to){
	std::ofstream of_a(to, std::ios_base::binary | std::ios_base::app);
	std::ifstream if_b(from, std::ios_base::binary);

	of_a.seekp(0, std::ios_base::end);
	of_a << if_b.rdbuf();
	of_a.close();
	if_b.close();
}

//***********************************************************************


void System::printCommandList(){
	std::cout << "echo STRING - prints the String to command line.\n"
				 "ls FILENAME - prints the current folder files.\n"
				 "history - prints the current user last 15 commands (avoiding ambiguity)\n"
				 "read -----------------------------\n"
				 "touch FILENAME - if file not found, makes a file. if file already found changes timestamp of the given file\n"
				 "cat FILENAME - prints all the file content\n"
				 "head FILENAME NUMBER - prints the first NUMBER of lines of given file (default NUMBER = 10)\n"
				 "tail FILENAME NUMBER = prints the last NUMBER of lines of given file (default NUMBER = 10)\n"
				 "copy SOURCEFILE TOFILE - copies SOURCEFILE to TOFILE\n"
				 "move SOURCEFILE TOFILE - moves the content of SORCESFILE to TOFILE (note SOURCEFILE won't be found after this command)\n"
				 "SOURCEFILE > TOFILE - chains the SOURCESFILE to TOFILE\n"
				 "TOFILE < SOURCEFILE - chains the SOURCESFILE to TOFILE\n"
				 "diff FILE1 FILE2 - prints the difference between FILE1 and FILE2\n"
				 "diff3 FILE1 FILE2 FILE3 - prints the diffrence between all 3 files.\n"
				 "chmod FILENAME NUMBER - sets a new permission to the file or directory.(note NUMBER has to be suitable)\n"
				 "find FILENAME - checks if the FILENAME exists in the current folder.\n"
				 "mkdir NAME - makes a new directory of the given NAME in the current path.\n"
				 "rmdir NAME - delete a directory in the current path, Only if the directory is empty.\n"
				 "show privacy FILENAME - shows the permissions of the file or directory.\n"
				 "date - shows today date.\n"
				 "fgrep STRING - search files for lines that matches fixed STRING.\n"
				 "locate FILENAME - find the file in all of the system.(note this command is not like find!).\n"
				 "look STRING - display lines begginning with a given STRING." << endl;
}

//************************************************************************************

void System::printDate(){
	time_t timeToday;
	time(&timeToday);
	cout << asctime(localtime(&timeToday));
}


//**************************************************************************************




















