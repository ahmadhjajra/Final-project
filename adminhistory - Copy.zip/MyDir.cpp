/*
 * MyDir.cpp
 *
 *  Created on: Oct 26, 2020
 *      Author: user
 */

#include "MyDir.h"

MyDir::MyDir() {
	// TODO Auto-generated constructor stub

}

MyDir::~MyDir() {
	// TODO Auto-generated destructor stub
}

