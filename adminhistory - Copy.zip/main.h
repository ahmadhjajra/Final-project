/*
 * main.h
 *
 *  Created on: Oct 23, 2020
 *      Author: user
 */

#ifndef MAIN_H_
#define MAIN_H_

class main {
public:
	main();
	virtual ~main();
};

#endif /* MAIN_H_ */
