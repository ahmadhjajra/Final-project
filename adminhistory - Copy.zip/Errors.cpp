/*
 * Errors.cpp
 *
 *  Created on: Oct 23, 2020
 *      Author: user
 */

#include "Errors.h"

Errors::Errors() {
	// TODO Auto-generated constructor stub

}

Errors::~Errors() {
	// TODO Auto-generated destructor stub
}

